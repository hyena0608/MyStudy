package chatserver.message;

public enum MessageType {
    ROOM,
    ONTTOONE,
    CLIENTINFO
}
