
import chatserver.BaseChatServer;

public class ChatServerApplication {

    public static void main(String[] args) {
        new BaseChatServer().chatServerStart();
    }

}

