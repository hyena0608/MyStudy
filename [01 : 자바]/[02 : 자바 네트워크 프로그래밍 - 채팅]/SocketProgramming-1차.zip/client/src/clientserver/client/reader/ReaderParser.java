package clientserver.client.reader;

import clientserver.client.Client;

public class ReaderParser {

    public void parse(String readMessage) {

        if (isCommand(readMessage)) {

        } else if (isSendMessage(readMessage)) {

        }

    }

    public boolean isCommand(String readMessage) {
        if (readMessage.substring(0, 0).equals("/")) {
            return true;
        }
        return false;
    }

    public boolean isSendMessage(String readMessage) {
         if (readMessage.substring(0, 0) != "/") {
             return false;
         }
         return true;
    }
}
