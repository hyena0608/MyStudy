package clientserver.client.reader;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ClientReader implements Runnable {

    private BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
    private ReaderParser readerParser = new ReaderParser();

    public String read() throws IOException {
        return bufferedReader.readLine();
    }

    @Override
    public void run() {
        while (true) {
            try {
                String readMessage = read();
                readerParser.parse(readMessage);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
