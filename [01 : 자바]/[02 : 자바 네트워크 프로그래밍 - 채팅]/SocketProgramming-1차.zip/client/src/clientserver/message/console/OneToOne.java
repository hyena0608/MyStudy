package clientserver.message.console;

import clientserver.message.console.MessageConsole;

public class OneToOne {

    public void print(String json) {
        System.out.println("[귓속말]" + json);
    }
}
