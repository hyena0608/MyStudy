package clientserver.message.console;

public interface MessageFactory {
}
