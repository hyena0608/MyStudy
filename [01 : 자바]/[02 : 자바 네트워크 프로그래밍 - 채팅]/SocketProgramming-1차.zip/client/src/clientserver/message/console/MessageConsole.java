package clientserver.message.console;

public interface MessageConsole {
    abstract void print(String json);
}
