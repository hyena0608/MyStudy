import clientserver.BaseClientServer;

public class ClientServerApplication {

    public static void main(String[] args) {
        new BaseClientServer().clientServerStart();
    }

}
